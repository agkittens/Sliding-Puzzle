
using UnityEngine;
using UnityEngine.UI;

public class timer : MonoBehaviour
{

    public float duration = 60.0f; 
    private float left;
    public GameObject circle;
    void Start()
    {
        circle = GameObject.Find("TimerCircle");
        left = duration;


    }

    void Update()
    {
        left -= Time.deltaTime;
        circle.GetComponent<Image>().fillAmount = left/duration;

        if (left <= 0.0f)
        {
            Debug.Log("Timer expired!");
            left = 0.0f; 
        }
    }
}

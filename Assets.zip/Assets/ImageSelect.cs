
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Nobi.UiRoundedCorners;

public class ImageSelect : MonoBehaviour
{
    public Sprite isSelectedImage;
    public string selection = "1";
    public string folder = "";
    private  List<GameObject> objects = new List<GameObject>();

    public float padding = 100f;

    void Start()
    {


        string[] filePaths = Directory.GetFiles("Assets/Resources/" + folder, "*.jpg");

        float totalWidth = GetComponent<RectTransform>().rect.width - (padding * 2f);
        float offset = totalWidth / (filePaths.Length-1);

        for (int i = 0; i < filePaths.Length; i++)
        {
            // create image object
            GameObject imageObject = new GameObject("SelectionImg");
            imageObject.transform.SetParent(this.transform);

            GameObject childObject = new GameObject("IsSelectedObj");
            childObject.transform.SetParent(imageObject.transform);


            // add components
            Image imageComponent = imageObject.AddComponent<Image>();
            ImageWithRoundedCorners script =  imageObject.AddComponent<ImageWithRoundedCorners>();
            script.radius = 10;
            Image imageSelectedComponent = childObject.AddComponent<Image>();


            Toggle toggleComponent = imageObject.AddComponent<Toggle>();
            toggleComponent.group = this.GetComponent<ToggleGroup>();
            toggleComponent.onValueChanged.AddListener(OnToggleValueChanged);
            objects.Add(imageObject);

            SpritePath spritePath =imageObject.AddComponent<SpritePath>();





            // load image
            string name = Path.GetFileNameWithoutExtension(filePaths[i]);
            imageComponent.sprite = Resources.Load<Sprite>(folder + "/" + name);
            imageSelectedComponent.sprite = isSelectedImage;
            spritePath.path = folder + "/" + name;


            // position
            float currentPosition = padding + offset * (float)i;
            Vector3 newPosition = new Vector3(currentPosition, 0f, 0f) ;
            imageObject.transform.localPosition = newPosition;


        }





    }

    void OnToggleValueChanged(bool isOn)
    {
        foreach (GameObject obj in objects)
        {
            obj.GetComponentsInChildren<Image>().Last().enabled = obj.GetComponent<Toggle>().isOn;

            if (obj.GetComponent<Toggle>().isOn)
            {
                string path = obj.GetComponent<SpritePath>().path;
                PlayerPrefs.SetString("path", path);

            }


        }

    }


}

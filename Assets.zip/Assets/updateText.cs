
using UnityEngine;
using UnityEngine.UI;

public class updateText : MonoBehaviour
{
    private Slider slider;
    private Text txt;

    void Start()
    {

        slider = GetComponentInParent<Slider>();
        txt = GetComponent<Text>();
        UpdateText(slider.value);
        slider.onValueChanged.AddListener(UpdateText);
        
    }

    void UpdateText(float a)
    {
        PlayerPrefs.SetInt("Size",(int)a);
        txt.text = a.ToString() + "x" + a.ToString();
    }
}

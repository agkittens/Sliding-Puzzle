
using UnityEngine;

public class SpritePath : MonoBehaviour
{
    public string path;
}


using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class Initialize : MonoBehaviour
{
    public int size;
    public int parts;
    public List<Sprite> sprites = new List<Sprite>();


    void Start()
    {
        size = PlayerPrefs.GetInt("Size");
        parts = size * size;
        Sprite original = Resources.Load<Sprite>(PlayerPrefs.GetString("path"));

        CutSprite(original);


        // dodatkowe tworzenie nowych obrazokow z tej listy
        foreach (Sprite sprite in sprites)
        {
            GameObject imageObject = new GameObject("img");
            imageObject.transform.SetParent(this.transform);
            Image imageComponent = imageObject.AddComponent<Image>();
            imageComponent.sprite = sprite;

        }

    }

    void CutSprite(Sprite original)
    {
        float partWidth = original.textureRect.width / size;
        float partHeight = original.textureRect.height / size;

        for (int row = 0; row < size; row++)
        {
            for (int col = 0; col < size; col++)
            {
                Rect rect = new Rect(col * partWidth, row * partHeight, partWidth, partHeight);

                Sprite part = Sprite.Create(original.texture, rect, new Vector2(0.5f, 0.5f), 100);
                sprites.Add(part);

            }
        }
    }



}
